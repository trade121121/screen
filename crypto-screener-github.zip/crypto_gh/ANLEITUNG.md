# Crypto Bottom Screener — GitHub Setup

Läuft täglich automatisch in der Cloud (GitHub Actions, kostenlos),
schreibt ein Dashboard auf deine eigene Website (GitHub Pages)
und schickt einen Telegram-Report. Kein PC nötig.

## Einmaliges Setup (~10 Minuten)

### 1. GitHub Account + Repository
1. github.com → Account erstellen (falls nicht vorhanden)
2. Oben rechts **+** → **New repository**
3. Name: `crypto-screener` → **Public** (nötig für kostenloses Pages) → Create

### 2. Dateien hochladen
1. Im neuen Repo: **uploading an existing file** (Link auf der Startseite)
2. Diese Dateien/Ordner per Drag & Drop hochladen:
   - `screener.py`
   - `.github/workflows/screener.yml` (Ordnerstruktur beibehalten!)
     → Falls Drag&Drop die Ordner nicht übernimmt: **Add file → Create new file**,
       als Dateiname `.github/workflows/screener.yml` eintippen (GitHub legt
       die Ordner automatisch an) und den Inhalt reinkopieren.
3. **Commit changes**

### 3. Telegram-Secrets hinterlegen
1. Repo → **Settings** → **Secrets and variables** → **Actions**
2. **New repository secret**:
   - Name: `TELEGRAM_TOKEN` → Wert: dein Bot-Token
   - Name: `TELEGRAM_CHAT_ID` → Wert: deine Chat-ID
   (Token/ID stehen so nie öffentlich im Code!)

### 4. GitHub Pages aktivieren
1. Repo → **Settings** → **Pages**
2. Source: **Deploy from a branch**
3. Branch: **main**, Ordner: **/docs** → **Save**

### 5. Ersten Lauf manuell starten
1. Repo → **Actions** → links "Daily Bottom Screener"
2. **Run workflow** → Run
3. ~5 Min warten → grüner Haken
4. Website: `https://DEIN-USERNAME.github.io/crypto-screener/`

Ab jetzt läuft der Screener **jeden Tag um ~02:20 Uhr** automatisch,
aktualisiert die Website und schickt den Telegram-Report mit Link.

## Parameter anpassen
Alle Schwellwerte stehen oben in `screener.py` (MIN_DAYS_ABOVE_EMA etc.).
Ändern → committen → nächster Lauf nutzt die neuen Werte.
Über **Actions → Run workflow** kannst du jederzeit manuell neu scannen.
